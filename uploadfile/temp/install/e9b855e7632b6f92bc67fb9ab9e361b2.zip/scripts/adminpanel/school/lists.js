	define(function (require) {
	    var $ = require('jquery');
	    var aci = require('aci');
	    require('bootstrap');
	    require('bootstrapValidator');

		$(function () {
			$("#reverseBtn").click(function(){
				aci.ReverseChecked('pid[]')
			});

			$("#deleteBtn").click(function(){
				var _arr = aci.GetCheckboxValue("pid[]");
				if(_arr.length==0)
				{
					alert("请先勾选明细");
					return false;
				}
				if(confirm('确定要删除吗?'))
				{
					$("#form_list").submit();
				}
			});
        
			 $(".delete-btn").click(function(){
				var v = $(this).val();
				if(confirm('确定要删除吗?'))
				{
					window.location.href= SITE_URL+ "adminpanel/school/delete_one/"+v;
				}
			});
            
            $('#validateform').bootstrapValidator({
				message: '输入框不能为空',
				feedbackIcons: {
					valid: 'glyphicon glyphicon-ok',
					invalid: 'glyphicon glyphicon-remove',
					validating: 'glyphicon glyphicon-refresh'
				},
				fields: {
					 SchoolName: {
						 validators: {
							notEmpty: {
								message: '园所名称 不可以为空'
							}
						 }
					 },
					 SchoolCode: {
						 validators: {
							notEmpty: {
								message: '园所编码 不可以为空'
							}
						 }
					 },
					 DistrinctId: {
						 validators: {
							notEmpty: {
								message: '区县ID 不可以为空'
							}
						 }
					 },
					 SchoolLevelId: {
						 validators: {
							notEmpty: {
								message: '园所类型ID 不可以为空'
							}
						 }
					 },
					 OwnershipId: {
						 validators: {
							notEmpty: {
								message: '所有制ID 不可以为空'
							}
						 }
					 },
					 TypeId: {
						 validators: {
							notEmpty: {
								message: '制别ID 不可以为空'
							}
						 }
					 },
					 KidNumber: {
						 validators: {
							notEmpty: {
								message: '儿童数量 不可以为空'
							}
						 }
					 },
					 TelPhone: {
						 validators: {
							notEmpty: {
								message: '园所电话 不可以为空'
							}
						 }
					 },
					 ContactName: {
						 validators: {
							notEmpty: {
								message: '联系人姓名 不可以为空'
							}
						 }
					 },
					 ContactPhone: {
						 validators: {
							notEmpty: {
								message: '联系人电话 不可以为空'
							}
						 }
					 },
					 DirectorName: {
						 validators: {
							notEmpty: {
								message: '园所负责人 不可以为空'
							}
						 }
					 },
					 DirectorPhone: {
						 validators: {
							notEmpty: {
								message: '园所负责人手机 不可以为空'
							}
						 }
					 },
					 Address: {
						 validators: {
							notEmpty: {
								message: '园所地址 不可以为空'
							}
						 }
					 },
					 QQ: {
						 validators: {
							notEmpty: {
								message: '联系人QQ 不可以为空'
							}
						 }
					 },
					 DesignBedNumber: {
						 validators: {
							notEmpty: {
								message: '设计床位数 不可以为空'
							}
						 }
					 },
					 ActualBedNumber: {
						 validators: {
							notEmpty: {
								message: '实际床位数 不可以为空'
							}
						 }
					 },
					 BigClassNumber: {
						 validators: {
							notEmpty: {
								message: '大班数 不可以为空'
							}
						 }
					 },
					 MidClassNumber: {
						 validators: {
							notEmpty: {
								message: '中班数 不可以为空'
							}
						 }
					 },
					 SmallClassNumber: {
						 validators: {
							notEmpty: {
								message: '小班数 不可以为空'
							}
						 }
					 },
					 CareClassNumber: {
						 validators: {
							notEmpty: {
								message: '托班数 不可以为空'
							}
						 }
					 },
					 SchoolArea: {
						 validators: {
							notEmpty: {
								message: '占地面积 不可以为空'
							}
						 }
					 },
					 GreenArea: {
						 validators: {
							notEmpty: {
								message: '绿化面积 不可以为空'
							}
						 }
					 },
					 IndoorArea: {
						 validators: {
							notEmpty: {
								message: '室内面积 不可以为空'
							}
						 }
					 },
					 OutdoorArea: {
						 validators: {
							notEmpty: {
								message: '室外面积 不可以为空'
							}
						 }
					 },
					 ActivityArea: {
						 validators: {
							notEmpty: {
								message: '活动室面积 不可以为空'
							}
						 }
					 },
					 BedroomArea: {
						 validators: {
							notEmpty: {
								message: '寝室面积 不可以为空'
							}
						 }
					 },
					 KitchenArea: {
						 validators: {
							notEmpty: {
								message: '厨房面积 不可以为空'
							}
						 }
					 },
					 NurseOfficeArea: {
						 validators: {
							notEmpty: {
								message: '保健室面积 不可以为空'
							}
						 }
					 },
					 IsolationRoomArea: {
						 validators: {
							notEmpty: {
								message: '隔离室面积 不可以为空'
							}
						 }
					 },
					 MultiFunctionHallArea: {
						 validators: {
							notEmpty: {
								message: '多功能厅面积 不可以为空'
							}
						 }
					 },
					 LanguageLabArea: {
						 validators: {
							notEmpty: {
								message: '语音室面积 不可以为空'
							}
						 }
					 },
					 ComputerRoomArea: {
						 validators: {
							notEmpty: {
								message: '微机室面积 不可以为空'
							}
						 }
					 },
					 SchoolEnvironment: {
						 validators: {
							notEmpty: {
								message: '园区环境 不可以为空'
							}
						 }
					 },
				}
			}).on('success.form.bv', function(e) {
				
				e.preventDefault();
				$("#dosubmit").attr("disabled","disabled");
				
				$.scojs_message("正在保存，请稍等...", $.scojs_message.TYPE_ERROR);
				$.ajax({
					type: "POST",
					url: edit?SITE_URL+"adminpanel/school/edit/"+id:SITE_URL+"adminpanel/school/add/",
					data:  $("#validateform").serialize(),
					success:function(response){
						var dataObj=jQuery.parseJSON(response);
						if(dataObj.status)
						{
							$.scojs_message('操作成功,3秒后将返回列表页...', $.scojs_message.TYPE_OK);
							aci.GoUrl(SITE_URL+'adminpanel/school/',1);
						}else
						{
							$.scojs_message(dataObj.tips, $.scojs_message.TYPE_ERROR);
							$("#dosubmit").removeAttr("disabled");
						}
					},
					error: function (request, status, error) {
						$.scojs_message(request.responseText, $.scojs_message.TYPE_ERROR);
						$("#dosubmit").removeAttr("disabled");
					}                  
				});
			
			}).on('error.form.bv',function(e){ $.scojs_message('带*号不能为空', $.scojs_message.TYPE_ERROR);$("#dosubmit").removeAttr("disabled");});
            
        });
});
